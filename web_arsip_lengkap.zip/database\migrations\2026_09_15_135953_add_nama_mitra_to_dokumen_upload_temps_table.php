<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('dokumen_upload_temps', function (Blueprint $table) {
            $table->string('nama_mitra')->nullable()->after('tanggal_dokumen');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('dokumen_upload_temps', function (Blueprint $table) {
            $table->dropColumn('nama_mitra');
        });
    }
};